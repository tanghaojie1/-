#ifndef __Uart4_H
#define __Uart4_H	


void Uart4Init();
void Uart4Send(char dat);
void Uart4SendStr(char *p);
extern bit busy4;
extern char wptr4;
extern char rptr4;
extern char buffer4[16];

#endif
#ifndef __Uart1_H
#define __Uart1_H	

void UartInit();
void UartSend(char dat);
void UartSendStr(char *p);
extern bit busy;
extern char wptr;
extern char rptr;
extern char buffer[16];

#endif

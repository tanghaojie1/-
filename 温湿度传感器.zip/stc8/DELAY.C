#include <DELAY.H>
#include <STC8.H>

/***������ʱ***/
void Delayms(uint x)		//@22.1184MHz
{
	uchar i, j;
	while(--x)
	{
	  _nop_();
	  _nop_();
	  i = 22;
	  j = 128;
	  do
	   {
		  while (--j);
	   }  
	  while (--i);
    }
}

/***΢����ʱ***/
void Delay_us(uint x)		//@22.1184MHz
{
	uchar i;
    while(--x)
	{
	  i = 1;
	  while (--i);
	}
}
